package com.kata.account.service.domain.exception;

public class InvalidAccountHistoryException extends AccountDomainException {
    public InvalidAccountHistoryException(String message) {
        super(message);
    }
}
