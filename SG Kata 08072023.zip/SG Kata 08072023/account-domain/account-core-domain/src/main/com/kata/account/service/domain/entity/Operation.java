package com.kata.account.service.domain.entity;

import com.kata.account.service.domain.exception.AccountDomainException;

public interface Operation {
    void execute();
    int getBalance();

    void validate() throws AccountDomainException;
}
