package com.kata.account.service.domain.exception;

public class InvalidDepositOperationException extends AccountDomainException {
    public InvalidDepositOperationException(String message) {
        super(message);
    }
}
