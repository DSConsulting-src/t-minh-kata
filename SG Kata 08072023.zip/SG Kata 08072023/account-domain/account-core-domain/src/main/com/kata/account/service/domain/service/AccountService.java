package com.kata.account.service.domain.service;

import com.kata.account.service.domain.entity.Account;
import com.kata.account.service.domain.entity.DepositOperation;
import com.kata.account.service.domain.entity.WithdrawalOperation;
import com.kata.account.service.domain.exception.AccountDomainException;

public interface AccountService {
    DepositOperation depositOn(Account account, int amount) throws AccountDomainException;

    WithdrawalOperation withdrawOn(Account account, int amount) throws AccountDomainException;
}
