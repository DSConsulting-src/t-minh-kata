package com.kata.account.service.domain.exception;

public class InvalidWithdrawalOperationException extends AccountDomainException {
    public InvalidWithdrawalOperationException(String message) {
        super(message);
    }
}
