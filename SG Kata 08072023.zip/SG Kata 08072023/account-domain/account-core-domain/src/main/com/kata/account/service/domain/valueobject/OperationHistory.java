package com.kata.account.service.domain.valueobject;

import com.kata.account.service.domain.entity.Account;
import com.kata.account.service.domain.exception.InvalidAccountHistoryException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Objects;

public final class OperationHistory {
    private final Account account;
    private final LocalDateTime start;
    private final LocalDateTime end;


    public OperationHistory(Account account, LocalDateTime start, LocalDateTime end) {
        this.account = account;
        this.start = start;
        this.end = end;
    }

    public void validate() throws InvalidAccountHistoryException {
        if (this.account == null) {
            throw new InvalidAccountHistoryException("Account cannot be null");
        }
        if (this.end.isBefore(this.start) || this.end.isEqual(this.start)) {
            throw new InvalidAccountHistoryException("The start time of a operation history must be before the end time");
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OperationHistory that = (OperationHistory) o;
        return Objects.equals(account, that.account) && Objects.equals(start, that.start) && Objects.equals(end, that.end);
    }

    @Override
    public int hashCode() {
        return Objects.hash(account, start, end);
    }
}
