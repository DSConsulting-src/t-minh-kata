package com.kata.account.service.domain.service;

import com.kata.account.service.domain.entity.Account;
import com.kata.account.service.domain.entity.DepositOperation;
import com.kata.account.service.domain.entity.WithdrawalOperation;
import com.kata.account.service.domain.exception.AccountDomainException;

public class AccountServiceImpl implements AccountService {
    @Override
    public DepositOperation depositOn(Account account, int amount) throws AccountDomainException {
        DepositOperation depositOperation = new DepositOperation(account, amount);
        depositOperation.validate();
        account.executeOperation(depositOperation);
        return depositOperation;
    }

    @Override
    public WithdrawalOperation withdrawOn(Account account, int amount) throws AccountDomainException {
        WithdrawalOperation withdrawalOperation = new WithdrawalOperation(account, amount);
        withdrawalOperation.validate();
        account.executeOperation(withdrawalOperation);
        return withdrawalOperation;
    }
}
