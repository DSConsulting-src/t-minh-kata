package com.kata.account.service.domain.entity;

import com.kata.account.service.domain.exception.AccountDomainException;
import com.kata.account.service.domain.exception.InvalidDepositOperationException;
import com.kata.account.service.domain.exception.InvalidWithdrawalOperationException;

import java.time.LocalDateTime;

public class WithdrawalOperation implements Operation {
    private Account account;
    private int balance;
    private LocalDateTime dateTime;
    private int amount;

    public WithdrawalOperation(Account account, int amount) {
        this.account = account;
        this.dateTime = LocalDateTime.now();
        this.amount = amount;
        this.balance = account.getBalance();;
    }

    public void validate() throws AccountDomainException {
        if (this.amount <= 0) {
            throw new InvalidWithdrawalOperationException("Withdrew amount must be positive");
        } else if (this.amount > this.balance) {
            throw new InvalidWithdrawalOperationException("Withdrew amount must be smaller than current balance");
        }
    }

    @Override
    public void execute() {
        balance -= amount;
    }

    public int getBalance() {
        return balance;
    }
}
