package com.kata.account.service.domain.entity;

import com.kata.account.service.domain.exception.AccountDomainException;
import com.kata.account.service.domain.exception.InvalidDepositOperationException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DepositOperation implements Operation {
    private Account account;
    private int balance;
    private LocalDateTime dateTime;
    private int amount;

    public DepositOperation(Account account, int amount) {
        this.account = account;
        this.dateTime = LocalDateTime.now();
        this.amount = amount;
        this.balance = this.account.getBalance();
    }

    @Override
    public void validate() throws AccountDomainException {
        if (this.amount <= 0) {
            throw new InvalidDepositOperationException("Deposit amount must be positive");
        }
    }

    @Override
    public void execute() {
        balance += amount;
    }

    @Override
    public int getBalance() {
        return balance;
    }
}
