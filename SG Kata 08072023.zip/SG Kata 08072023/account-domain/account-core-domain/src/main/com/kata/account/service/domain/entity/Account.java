package com.kata.account.service.domain.entity;

import com.kata.account.service.domain.exception.InvalidDepositOperationException;
import com.kata.account.service.domain.exception.InvalidWithdrawalOperationException;

import java.util.ArrayList;
import java.util.List;

public class Account {
    private int balance;

    public Account() {
    }

    public int getBalance() {
        return balance;
    }

    public void executeOperation(Operation operation) {
        operation.execute();
        balance = operation.getBalance();
    }
}
