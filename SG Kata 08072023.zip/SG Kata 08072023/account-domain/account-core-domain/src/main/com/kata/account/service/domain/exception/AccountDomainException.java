package com.kata.account.service.domain.exception;

public class AccountDomainException extends Exception {
    public AccountDomainException(String message) {
        super(message);
    }
}
