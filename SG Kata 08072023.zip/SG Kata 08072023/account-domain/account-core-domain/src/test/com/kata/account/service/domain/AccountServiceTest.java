package com.kata.account.service.domain;

import com.kata.account.service.domain.entity.Account;
import com.kata.account.service.domain.entity.DepositOperation;
import com.kata.account.service.domain.exception.AccountDomainException;
import com.kata.account.service.domain.service.AccountServiceImpl;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AccountServiceTest {
    private AccountServiceImpl subject;

    @Test
    public void depositIncreaseAccountBalance () throws AccountDomainException {
        subject = new AccountServiceImpl();
        Account account = new Account();
        subject.depositOn(account, 1000);
        assertEquals(1000, account.getBalance());
    }

    @Test
    public void withdrawalDecreaseAccountBalance () throws AccountDomainException {
        subject = new AccountServiceImpl();
        Account account = new Account();
        subject.depositOn(account, 1000);
        subject.withdrawOn(account, 500);
        assertEquals(500, account.getBalance());
    }
}
