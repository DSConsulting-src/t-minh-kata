package com.kata.account.service.domain;

import com.kata.account.service.domain.entity.Account;
import com.kata.account.service.domain.entity.WithdrawalOperation;
import com.kata.account.service.domain.exception.AccountDomainException;
import com.kata.account.service.domain.exception.InvalidWithdrawalOperationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class WithdrawalOperationTest {
    private WithdrawalOperation subject;

    @Test
    public void withdrawDecreaseAccountBalance () {
        Account account = Mockito.mock(Account.class);
        Mockito.when(account.getBalance()).thenReturn(3000);
        subject = new WithdrawalOperation
                (account,2000);
        subject.execute();
        assertEquals(1000, subject.getBalance());
    }

    @Test
    public void withdrewAmountMustBeGreaterThanBalance() {
        Account account = Mockito.mock(Account.class);
        Mockito.when(account.getBalance()).thenReturn(1000);
        subject = new WithdrawalOperation(account, 2000);
        assertThrows(InvalidWithdrawalOperationException.class, () -> subject.validate());
    }

    @Test
    public void withdrewAmountMustBeGreaterThanZero() {
        Account account = Mockito.mock(Account.class);
        Mockito.when(account.getBalance()).thenReturn(1000);
        subject = new WithdrawalOperation(account, 0);
        assertThrows(InvalidWithdrawalOperationException.class, () -> subject.validate());
    }
}
