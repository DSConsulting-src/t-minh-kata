package com.kata.account.service.domain;

import com.kata.account.service.domain.entity.Account;
import org.junit.jupiter.api.Test;

public class AccountTest {
    private Account subject;

    @Test
    public void newlyCreatedAccountHasZeroBalance() {
        subject = new Account();
        assert(subject.getBalance() == 0);
    }
}
