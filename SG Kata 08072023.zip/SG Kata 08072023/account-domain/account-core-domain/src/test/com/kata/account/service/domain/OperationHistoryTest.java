package com.kata.account.service.domain;

import com.kata.account.service.domain.exception.InvalidAccountHistoryException;
import com.kata.account.service.domain.valueobject.OperationHistory;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class OperationHistoryTest {
    private OperationHistory subject;

    @Test
    public void endDateMustBeAfterStartDate() {
        subject = new OperationHistory(null, LocalDateTime.of(2023, 7, 31, 0, 0),
                LocalDateTime.of(2023, 7, 1, 0, 0));
        assertThrows(InvalidAccountHistoryException.class, () ->
                subject.validate());

        subject = new OperationHistory(null, LocalDateTime.of(2023, 7, 31, 0, 0),
                LocalDateTime.of(2023, 7, 31, 0, 0));
        assertThrows(InvalidAccountHistoryException.class, () ->
                subject.validate());
    }


}
