package com.kata.account.service.domain;

import com.kata.account.service.domain.entity.Account;
import com.kata.account.service.domain.entity.DepositOperation;
import com.kata.account.service.domain.exception.AccountDomainException;
import com.kata.account.service.domain.exception.InvalidDepositOperationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class DepositOperationTest {
    private DepositOperation subject;
    @Test
    public void depositIncreaseAccountBalance () {
        Account account = Mockito.mock(Account.class);
        Mockito.when(account.getBalance()).thenReturn(0);
        subject = new DepositOperation(account, 3000);
        subject.execute();
        assertEquals(3000, subject.getBalance());
    }

    @Test
    public void depositAmountMustBePositive() {
        Account account = Mockito.mock(Account.class);
        Mockito.when(account.getBalance()).thenReturn(0);
        subject = new DepositOperation(account,0);
        assertThrows(InvalidDepositOperationException.class, () -> subject.validate());
        subject = new DepositOperation(account,-3000);
        assertThrows(InvalidDepositOperationException.class, () -> subject.validate());
    }
}
