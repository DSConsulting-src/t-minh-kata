package com.kata.account.service.ports.output;

import com.kata.account.service.domain.entity.Account;
import com.kata.account.service.domain.entity.Operation;
import com.kata.account.service.domain.valueobject.OperationHistory;

import java.util.List;

public interface AccountRepository {
    void saveAccount(Account account);
    void saveOperation(Operation operation);
    List<Operation> getOperationHistory(OperationHistory history);
}
