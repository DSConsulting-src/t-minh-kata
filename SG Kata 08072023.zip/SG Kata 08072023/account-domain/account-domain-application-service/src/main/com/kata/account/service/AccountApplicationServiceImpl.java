package com.kata.account.service;

import com.kata.account.service.domain.entity.Account;
import com.kata.account.service.domain.entity.DepositOperation;
import com.kata.account.service.domain.entity.Operation;
import com.kata.account.service.domain.entity.WithdrawalOperation;
import com.kata.account.service.domain.exception.AccountDomainException;
import com.kata.account.service.domain.service.AccountService;
import com.kata.account.service.domain.valueobject.OperationHistory;
import com.kata.account.service.ports.input.AccountApplicationService;
import com.kata.account.service.ports.output.AccountRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AccountApplicationServiceImpl implements AccountApplicationService {
    private AccountService accountService;
    private AccountRepository accountRepository;

    public AccountApplicationServiceImpl(AccountService accountService, AccountRepository accountRepository) {
        this.accountService = accountService;
        this.accountRepository = accountRepository;
    }

    @Override
    public void depositOn(Account account, int amount) throws AccountDomainException {
        DepositOperation depositOperation = accountService.depositOn(account, amount);
        accountRepository.saveAccount(account);
        accountRepository.saveOperation(depositOperation);
    }

    @Override
    public void withdrawOn(Account account, int amount) throws AccountDomainException {
        WithdrawalOperation withdrawalOperation = accountService.withdrawOn(account, amount);
        accountRepository.saveAccount(account);
        accountRepository.saveOperation(withdrawalOperation);
    }

    @Override
    public List<Operation> getOperationHistory(Account account, LocalDateTime start, LocalDateTime end) throws AccountDomainException {
        OperationHistory operationHistory = new OperationHistory(account, start, end);
        operationHistory.validate();
        return accountRepository.getOperationHistory(operationHistory);
    }
}
