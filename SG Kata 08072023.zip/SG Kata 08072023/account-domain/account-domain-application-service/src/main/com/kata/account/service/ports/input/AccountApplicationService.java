package com.kata.account.service.ports.input;

import com.kata.account.service.domain.entity.Account;
import com.kata.account.service.domain.entity.Operation;
import com.kata.account.service.domain.exception.AccountDomainException;

import java.time.LocalDateTime;
import java.util.List;

public interface AccountApplicationService {
    void depositOn(Account account, int amount) throws AccountDomainException;
    void withdrawOn(Account account, int amount) throws AccountDomainException;
    List<Operation> getOperationHistory(Account account, LocalDateTime start, LocalDateTime end) throws AccountDomainException;
}
